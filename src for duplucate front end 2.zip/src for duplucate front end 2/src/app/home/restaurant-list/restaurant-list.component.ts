import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
@Component({
selector: 'app-restaurant-list',
templateUrl: './restaurant-list.component.html',
styleUrls: ['./restaurant-list.component.scss']
})
export class RestaurantListComponent implements OnInit {
restaurants: any[] = [];
filteredRestaurants: any[] = [];
searchText = '';
isRestaurantOwner = false; // Change this based on the user's role

constructor() { }

ngOnInit(): void {
this.restaurants = [
{
name: 'Restaurant 1',
location: 'Location 1',
specialty: 'Specialty 1',
menu: ['Item 1', 'Item 2', 'Item 3'],
additionalFeatures: ['Feature 1', 'Feature 2']
},
{
name: 'Restaurant 2',
location: 'Location 2',
specialty: 'Specialty 2',
menu: ['Item 1', 'Item 2', 'Item 3'],
additionalFeatures: ['Feature 1', 'Feature 2']
}
];
this.filteredRestaurants = this.restaurants;
}

addRestaurant() {
// Implement the logic to add a Restaurant
}

editRestaurant() {
// Implement the logic to edit a Restaurant
}

deleteRestaurant() {
// Implement the logic to delete a Restaurant
}

}